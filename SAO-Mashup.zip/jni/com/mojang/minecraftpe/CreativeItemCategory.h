#pragma once

enum class CreativeItemCategory : int {
	BLOCKS = 1,
	DECORATIONS,
	TOOLS,
	ITEMS
};