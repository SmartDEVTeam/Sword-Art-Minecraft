#pragma once

class TextureData {
public:
	int width, height;
	char* pixels;
};
