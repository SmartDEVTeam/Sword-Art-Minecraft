#pragma once
#include <string>

class AppPlatform {
	public:
	std::string getEdition() const;
};
