#pragma once

class AppPlatform_android {
	public:
	int getScreenType() const;
};
