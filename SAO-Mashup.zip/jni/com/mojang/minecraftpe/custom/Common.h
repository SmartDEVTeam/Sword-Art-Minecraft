#pragma once
#include <string>

class Common {
	public:
	std::string getGameVersionString();
	std::string getGameDevVersionString();
};
