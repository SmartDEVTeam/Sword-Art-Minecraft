#pragma once

enum class DataItemType : int {
	STRING = 4,
	ITEMINSTANCE,
	
}


struct SynchedEntityData {
	char filler[16];

};
