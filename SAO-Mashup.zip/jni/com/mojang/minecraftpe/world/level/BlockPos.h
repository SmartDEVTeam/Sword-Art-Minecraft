#pragma once

struct BlockPos {
	int x, y, z;
};

