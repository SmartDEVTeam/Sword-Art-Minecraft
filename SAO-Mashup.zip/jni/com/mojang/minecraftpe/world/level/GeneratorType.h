#pragma once

enum class GeneratorType : int {
	LEGACY,
	INFINITE,
	FLAT,
	HELL,
	NONE
};
